﻿using UnityEngine;

public class ShowOnlyAttribute : PropertyAttribute
{
}